# app.py
import time
from metrics import get_system_metrics
from azure_monitor import send_metrics_to_azure
from dotenv import load_dotenv
load_dotenv()

if __name__ == '__main__':
    while True:
        metrics = get_system_metrics()
        status = send_metrics_to_azure(metrics)
        print(f"Metrics sent. Status code: {status}")
        time.sleep(60)  # wait 60 seconds before sending again