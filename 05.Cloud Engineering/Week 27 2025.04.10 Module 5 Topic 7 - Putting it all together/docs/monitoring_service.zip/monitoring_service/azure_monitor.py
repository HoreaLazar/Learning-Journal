# azure_monitor.py
import os
import json
import requests
from datetime import datetime
from dotenv import load_dotenv
load_dotenv()

TENANT_ID = os.getenv("AZURE_TENANT_ID", "<your-tenant-id>")
CLIENT_ID = os.getenv("AZURE_CLIENT_ID", "<your-client-id>")
CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET", "<your-client-secret>")
WORKSPACE_ID = os.getenv("AZURE_WORKSPACE_ID", "<your-workspace-id>")
AZURE_MONITOR_URL=f"https://{WORKSPACE_ID}.ods.opinsights.azure.com/api/logs?api-version=2016-04-01"

def get_access_token():
    url = "https://login.microsoftonline.com/<tenant_id>/oauth2/token"
    data = {
        'grant_type': 'client_credentials',
        'client_id': '<client_id>',
        'client_secret': '<client_secret>',
        'resource': 'https://monitor.azure.com/'
    }
    response = requests.post(url, data=data)
    return response.json()['access_token']


def send_metrics_to_azure(metrics):
    api_url = os.getenv('AZURE_MONITOR_URL')
    access_token = os.getenv('AZURE_MONITOR_TOKEN')

    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {access_token}'
    }

    payload = [{
        'time': datetime.utcnow().isoformat() + 'Z',
        'data': metrics
    }]

    response = requests.post(api_url, headers=headers, json=payload)
    return response.status_code